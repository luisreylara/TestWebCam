/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opencvejemplo1;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.opencv.imgcodecs.Imgcodecs;
import javax.imageio.ImageIO;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
// import org.opencv.highgui.Highgui;

 /**  
  * Creates a BufferedImage object from a Matrix.  
  */

//http://docs.opencv.org/java/2.4.2/org/opencv/highgui/Highgui.html#imread(java.lang.String, int)
//Currently, the following file formats are supported:
//
//Windows bitmaps - *.bmp, *.dib (always supported)
//JPEG files - *.jpeg, *.jpg, *.jpe (see the *Notes* section)
//JPEG 2000 files - *.jp2 (see the *Notes* section)
//Portable Network Graphics - *.png (see the *Notes* section)
//Portable image format - *.pbm, *.pgm, *.ppm (always supported)
//Sun rasters - *.sr, *.ras (always supported)
//TIFF files - *.tiff, *.tif (see the *Notes* section)

public class MatToBufImg {
     Mat matrix;
     MatOfByte mob;
     String fileExten;

     // The file extension string should be ".jpg", ".png", etc
 	public MatToBufImg(){
 	}
     // The file extension string should be ".jpg", ".png", etc
	public MatToBufImg(Mat amatrix, String fileExt){
		matrix = amatrix;
		fileExten = fileExt;
		
	}
	
	public void setMatrix(Mat amatrix, String fileExt ){
		matrix = amatrix;
		fileExten = fileExt;
		mob = new MatOfByte();
	}
	
	public BufferedImage getBufferedImage(){
		//convert the matrix into a matrix of bytes appropriate for
		//this file extension
		Imgcodecs.imencode(fileExten, matrix ,mob); 
		//convert the "matrix of bytes" into a byte array
		 byte[] byteArray = mob.toArray();
		 BufferedImage bufImage = null;
		 try {
		        InputStream in = new ByteArrayInputStream(byteArray);
		        bufImage = ImageIO.read(in);
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		 return bufImage;
	}
}
